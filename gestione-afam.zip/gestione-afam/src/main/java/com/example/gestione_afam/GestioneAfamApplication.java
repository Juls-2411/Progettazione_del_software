package com.example.gestione_afam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestioneAfamApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestioneAfamApplication.class, args);
	}

}
